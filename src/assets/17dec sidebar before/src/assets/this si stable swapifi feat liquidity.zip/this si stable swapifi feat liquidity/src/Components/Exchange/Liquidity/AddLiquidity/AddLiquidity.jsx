import React from 'react'
import as from "./AddLiquidity.module.css"
// import { IoIosArrowRoundBack } from 'react-icons/io'
import { IoSettings } from 'react-icons/io5'
import { HiArrowNarrowLeft } from "react-icons/hi";
import { IoIosArrowDown } from "react-icons/io";
import { useNavigate } from 'react-router-dom';

const AddLiquidity = () => {

    const navigate = useNavigate();

    return (
        <div className={`${as.AddLiquidityCont}`}    >


            {/* AddLiquidityHead */}
            <div className={`${as.AddLiquidityHead} d-flex align-items-center justify-content-between`}    >

                <HiArrowNarrowLeft onClick={()=>navigate("/Exchange/Liquidity")} />
                <span className='fw-bold'   >Add Liquidity</span>
                <span><IoSettings></IoSettings></span>

            </div>


            {/* pair& amount  */}
            <div className={`${as.pairAmount} mt-2 d-flex justify-content-between align-items-center`}   >
                <span>Pair & Amount</span>
                <span className='mt-1'  >Clear All</span>
            </div>

            {/* coin $ balance  */}
            <div className={`${as.coinBalanceCont} justify-content-between d-flex`}   >

                {/* part 1 of 2 */}
                <div className={`${as.coinBalanceA} d-flex`}   >

                    <span><img src={require("../../../../assets/icon.png")}    ></img></span>
                    <span  className='d-flex align-items-center justify-content-center fw-bold pb-1'   >BIT</span>
                    <IoIosArrowDown></IoIosArrowDown>
                </div>

                {/* part 2 of 2 */}
                <div className={`${as.coinBalanceB}`}   >

                    {/* <span> <img></img> </span>
                    <span></span>
                    <IoIosArrowDown></IoIosArrowDown> */}
                </div>


            </div>


        </div>
    )
}

export default AddLiquidity