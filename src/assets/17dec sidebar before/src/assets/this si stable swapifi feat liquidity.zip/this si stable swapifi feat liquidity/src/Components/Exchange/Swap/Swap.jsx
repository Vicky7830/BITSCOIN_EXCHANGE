import React, { useState } from 'react'
import as from "./Swap.module.css"
import { NavLink } from 'react-router-dom'
import { IoSettings } from 'react-icons/io5'
import { IoIosArrowDown } from 'react-icons/io'
import icon from "../../../assets/icon.png"
import { FaWallet } from "react-icons/fa6";
import { CgArrowsExchangeV } from "react-icons/cg";
import TokenList from '../TokenList/TokenList'
import Setting from '../Setting/Setting'

const Swap = () => {

    // state 
    const [tokenListVis, setTokenListVis] = useState(false)
    const [settingVis, setSettingVis] = useState(false)


    // useEffect(() => {

    //     //link bottom underline 
    //     //  classs toggler  
    //     const Navlinks = document.querySelectorAll(".SwapLink")
    //     console.log(Navlinks);

    //     Navlinks.forEach(navLink => {
    //         navLink.addEventListener('click', () => {
    //             // navLink.classList.toggle("active")
    //             document.querySelector('.active_it')?.classList.remove('active_it');
    //             navLink.classList.add('active_it')
    //         })
    //     })
    // })


    // token visibility toggler 
    const TokenListVisHandler = () => {
        setTokenListVis(!tokenListVis)
    }

    // Setting visibility toggler 

    const SettingVisHandler = () => {
        setSettingVis(!settingVis)
    }



    return (
        <>

            {/* {setting container } */}

            {settingVis ? <Setting SettingVisHandler={SettingVisHandler}   ></Setting> : null}


            {/* TokenList Componenet  */}
            {tokenListVis ? <TokenList TokenListVisHandler={TokenListVisHandler}   ></TokenList> : null}



            {/* setting container  */}
            <div className={`${as.settingCont} d-flex gap-1 align-items-center`}   >
                <IoSettings className='cursor-pointer ' onClick={() => setSettingVis(!settingVis)} ></IoSettings>
                <h3 className='d-inline-block text-dark' >Swap</h3>
            </div>


            {/* swap (from) from container  */}
            <div className={`${as.swapFromhead} d-flex align-items-center`}   >
                <span className=' fw-bold ps-2 pe-2 text-secondary'   >From</span>
                <div className={`${as.swapImgFromCont}`}   >
                    <img alt='coin_' loading='lazy' src={icon} ></img>
                </div>
                <span className='ps-2 pe-1 fw-bold'  >BNB</span>
                <IoIosArrowDown className='cursor-pointer ' onClick={() => TokenListVisHandler()}  ></IoIosArrowDown>
            </div>

            {/* from input group/ */}
            <div className={`${as.fromInputCont}`}  >
                <input type='number' value="0.0"  ></input>
                <span>USD</span>
            </div>


            {/* <reverse    */}
            <div className={`${as.exchangeSymboldCont}`}  >
                <CgArrowsExchangeV className='cursor-pointer' />
            </div>


            {/* swap to container  */}
            <div className={`${as.swapFromhead}  mt-2 d-flex align-items-center`}   >
                <span className=' fw-bold ps-2 pe-2 text-secondary'   >To</span>
                <div className={`${as.swapImgFromCont}`}   >
                    <img alt='coin_' loading='lazy' src={icon} ></img>
                </div>
                <span className='ps-2 pe-1 fw-bold'  >BNB</span>
                <IoIosArrowDown className='cursor-pointer ' onClick={() => TokenListVisHandler()} ></IoIosArrowDown>
            </div>


            {/* to input group  */}
            {/* from input group/ */}
            <div className={`${as.fromInputCont2}`}  >
                <input type='number' value="0.0"  ></input>
                {/* <span>USD</span> */}
            </div>

            {/* submit btn  */}
            <button className={`${as.swapSubmitBtn}`}   >
                <FaWallet></FaWallet>
                <span className='ps-2' >Connect Wallet</span>
            </button>
        </>
    )
}

export default Swap