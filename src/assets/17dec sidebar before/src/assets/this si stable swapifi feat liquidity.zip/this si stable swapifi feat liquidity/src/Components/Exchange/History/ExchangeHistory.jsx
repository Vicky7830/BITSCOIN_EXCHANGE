import React from 'react'

const ExchangeHistory = () => {
  return (
    <div>ExchangeHistory</div>
  )
}

export default ExchangeHistory