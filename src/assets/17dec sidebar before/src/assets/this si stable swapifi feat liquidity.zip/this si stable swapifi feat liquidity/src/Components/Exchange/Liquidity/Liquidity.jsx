import React, { useState } from 'react'

import as from "./Liquidity.module.css"
import { IoSettings } from 'react-icons/io5'
import { Link, useNavigate } from 'react-router-dom'
import { AiFillPlusCircle, AiOutlineQuestionCircle } from "react-icons/ai";
import { BiSolidGift } from "react-icons/bi";
import Setting from '../Setting/Setting';

const Liquidity = () => {

  const navigate = useNavigate();


  // state 
  const [settingVis, setSettingVis] = useState(false)

  
    // Setting visibility toggler 

    const SettingVisHandler = () => {
      setSettingVis(!settingVis)
  }




  return (
    <>

    {/* {setting container } */}

    {settingVis ? <Setting SettingVisHandler={SettingVisHandler}   ></Setting> : null}


      <div className={as.LiquidityContainer}    >

        {/* setting container  */}
        <div className={`${as.settingCont} d-flex gap-1 align-items-center`}   >
          <IoSettings className='cursor-pointer '  onClick={() => setSettingVis(!settingVis)}  ></IoSettings>
          <h3 className='d-inline-block text-dark' >Liquidity V3</h3>
        </div>


        <p className='mt-2'  >Add liquidity to get an LP NFT. <Link className='ps-1'   > Why V3 liquidity is better?</Link></p>

        {/* add liquidity buttons  */}
        <button className={`${as.Liquiditybtn} d-flex justify-content-center align-items-center gap-2 `} onClick={()=>navigate("/Exchange/Liquidity/add")} >Add Liquidity <AiFillPlusCircle /> </button>

        {/* your liquidity container  */}
        <div className={`${as.UrLiquidityCont}`}   >

          {/* heading   */}
          <div className={`${as.headCont} d-flex align-items-center justify-content-start gap-2`}   ><span className='fw-bold'   >Your Liquidity</span><AiOutlineQuestionCircle /></div>

          <p id={`${as.connectWalletp}`} className='d-flex align-items-center gap-1 '  >No liquidity found.</p>


          {/* top pools  contianer */}
          <div className={`${as.topPoolsContainer}`}   >

            <div className={`${as.headCont} d-flex align-items-center justify-content-start gap-2`}   ><span className='fw-bold'   >Top Polls</span><AiOutlineQuestionCircle /></div>

            {/* pool coins pair list  */}
            <ul className='mt-2 d-flex flex-column list-decoration-none'    >

              {/* 1 */}
              {/* array.map  on this li  */}
              {/* array.map  on this li  */}
              {/* array.map  on this li  */}
              {/* array.map  on this li  */}
              <li className='d-flex flex-row align-items-center justify-content-between'    >

                <div className={`${as.li1} d-flex text-white`}   >

                  {/* coins pair container  */}
                  <div className={`${as.coinpirsCont} d-flex justify-content-start`}  >

                    <img className={`${as.img1} z-2  pairimg`} loading='lazy' src={require("../../../assets/icon.png")}   ></img>
                    <img className={`${as.img2} z-1 pairimg`} loading='lazy' src={require("../../../assets/icon.png")}   ></img>

                  </div>

                  {/* coin pair content container  */}
                  <p className={`${as.pairContentCont}  ps-1 d-flex  `}  >
                    <span>USDT</span>/<span>WBNB</span>
                    <span   >0.08%</span>
                    <span>APR 39.08%   <BiSolidGift /> </span>
                  </p>

                </div>

                {/* tvl value                */}
                <div className={`${as.li2} `}   >
                  <p> TVL <span>$6 989 613.15</span></p></div>

              </li>

              {/* <li>sd</li> */}

            </ul>

            {/* your pools btn  */}
            <button className={`${as.allPoolsBtn} `}   > Your Pools</button>
          </div>

        </div>

      </div>
    </>

  )
}

export default Liquidity