import { RxCrossCircled } from "react-icons/rx";
import ad from "./WalletPopUp.module.css";
import { Link } from "react-router-dom";
import METAMASK_ICON from "../../assets/metamask-wallet.svg";
import TRUST_WALLET_ICON from "../../assets/trust-wallet.svg";
import BINANCE_WALLET_ICON from "../../assets/binance-wallet.svg";
import COINBASE_WALLET_ICON from "../../assets/coinbase-wallet.svg";
import WALLET_CONNECT_ICON from "../../assets/connect-wallet.svg";
import { useEffect, useState } from "react";
import { checkWalletExistance } from "../../utils";

const WalletPopUp = ({ popUpVisHandler, setAccount }) => {
  const [selectedWallet, setSelectedWallet] = useState("");

  //perform action on wallet select
  useEffect(() => {
    connectWallet();
  }, [selectedWallet]);

  //connect to wallet
  const connectWallet = async () => {
    let account = await checkWalletExistance(selectedWallet);
    setAccount(account);
  };

  //handle selected wallet
  const handleSelectedWallet = (wallet) => {
    setSelectedWallet(wallet);
  };

  return (
    <div>
      <div>
        <div className={`${ad.main}`}>
          <div className={`${ad.popUp}`}>
            <div className={`${ad.popupHeader} `}>
              <h4 className="fw-bold">Connect a Wallet</h4>
              <h1 className="cursor-pointer" onClick={popUpVisHandler}>
                <RxCrossCircled className="fw-bold cursor-pointer" size={20} />
              </h1>
            </div>

            <p className={`${ad.terms}`}>
              By connecting a wallet, you agree to <wbr></wbr> {"Bitswap's"}{" "}
              <Link to="#">Terms of Use</Link>
            </p>

            <div className={`${ad.contentGh} `}>
              <div className={`${ad.pannelCrypto} `}>
                {/* 1 */}
                <button
                  className={`${ad.buttonWallet} mt-4`}
                  onClick={() => handleSelectedWallet("metamask")}
                >
                  <span className={`${ad.buttonWalleta}`}>
                    <img
                      className={`${ad.buttonWalletaimg} img img-template`}
                      src={METAMASK_ICON}
                      alt="metamask"
                    ></img>
                  </span>

                  <span className={`${ad.buttonWalletb} fw-bold d-flex  `}>
                    Meta Mask
                  </span>
                </button>

                {/*2 */}
                <button
                  className={`${ad.buttonWallet} mt-3`}
                  onClick={() => handleSelectedWallet("trustwallet")}
                >
                  <span className={`${ad.buttonWalleta}`}>
                    <img
                      className={`${ad.buttonWalletaimg} img img-template`}
                      src={TRUST_WALLET_ICON}
                      alt="Trust Wallet"
                    ></img>
                  </span>

                  <span
                    className={`${ad.buttonWalletb} fw-bold d-flex align-items-center pt-1`}
                  >
                    Trust Wallet
                  </span>
                </button>

                {/* 3 */}
                <button
                  className={`${ad.buttonWallet} mt-3`}
                  onClick={() => handleSelectedWallet("binancechain")}
                >
                  <span className={`${ad.buttonWalleta}`}>
                    <img
                      className={`${ad.buttonWalletaimg} img img-template`}
                      src={BINANCE_WALLET_ICON}
                      alt="Binance Chain"
                    ></img>
                  </span>

                  <span
                    className={`${ad.buttonWalletb} fw-bold d-flex align-items-center pt-1`}
                  >
                    Binance Chain
                  </span>
                </button>

                {/* 4 */}
                <button
                  className={`${ad.buttonWallet} mt-3`}
                  onClick={() => handleSelectedWallet("coinbase")}
                >
                  <span className={`${ad.buttonWalleta}`}>
                    <img
                      className={`${ad.buttonWalletaimg} img img-template`}
                      src={COINBASE_WALLET_ICON}
                      alt="Coinbase Wallet"
                    ></img>
                  </span>

                  <span
                    className={`${ad.buttonWalletb} fw-bold d-flex align-items-center pt-1`}
                  >
                    Coinbase Wallet
                  </span>
                </button>

                {/* 5 */}
                <button
                  className={`${ad.buttonWallet} mt-3`}
                  onClick={() => handleSelectedWallet("walletconnect")}
                >
                  <span className={`${ad.buttonWalleta}`}>
                    <img
                      className={`${ad.buttonWalletaimg} img img-template`}
                      src={WALLET_CONNECT_ICON}
                      alt="Wallet Connect"
                    ></img>
                  </span>

                  <span
                    className={`${ad.buttonWalletb} fw-bold d-flex align-items-center pt-1`}
                  >
                    Wallet Connect
                  </span>
                </button>
              </div>

              <div className={ad.htr}>
                <hr className="hrline"></hr>
              </div>

              <div
                className={`${ad.walletquie} d-flex align-items-center justify-content-between mt-2`}
              >
                <h5 className={`${ad.textr1}  cursor-pointer fw-bold `}>
                  New to Ethereum wallets?
                </h5>
                <h5 className={`${ad.textr2} cursor-pointer fw-bold `}>
                  Learn More
                </h5>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default WalletPopUp;
