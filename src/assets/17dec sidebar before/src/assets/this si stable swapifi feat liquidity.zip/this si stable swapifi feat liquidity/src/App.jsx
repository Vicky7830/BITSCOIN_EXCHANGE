
import Home from './Components/Home/Home'
import Landing from './Components/Landing/Landing'
import Swap from './Components/Exchange/Swap/Swap';
import Exchange from './Components/Exchange/Exchange';

// css 
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'

// Route 
import { Route, Routes } from 'react-router-dom'
import Liquidity from './Components/Exchange/Liquidity/Liquidity';
import ExchangeHistory from './Components/Exchange/History/ExchangeHistory';
import BuyCrypto from './Components/Exchange/BuyCrypto/BuyCrypto';
import AddLiquidity from './Components/Exchange/Liquidity/AddLiquidity/AddLiquidity';


function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Home></Home>}>
          {/* default outlet :  landing page for home  */}
          <Route path="/" element={<Landing></Landing>}>
            {" "}
          </Route>

          {/* other outlets for home   */}

          {/* exchange/   */}
          <Route path="/Exchange" element={<Exchange></Exchange>}>
            {/* default outlet for exchnage :  swap page  */}
            <Route path="/Exchange" element={<Swap></Swap>}></Route>
            <Route path="/Exchange/Liquidity" element={<Liquidity></Liquidity>}></Route>
            <Route path="/Exchange/Liquidity/add" element={<AddLiquidity></AddLiquidity>}></Route>



            <Route path="/Exchange/History" element={<ExchangeHistory></ExchangeHistory>}></Route>
            <Route path="/Exchange/BuyCrypto" element={<BuyCrypto></BuyCrypto>}></Route>
          </Route>
        </Route>
      </Routes>
    </>
  );
}

export default App;
