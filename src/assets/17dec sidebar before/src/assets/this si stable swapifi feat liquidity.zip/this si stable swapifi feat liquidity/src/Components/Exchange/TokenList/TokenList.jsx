import React, { useEffect, useState } from 'react'
import as from "./TokenList.module.css"
import { MdClose } from 'react-icons/md'
import { IoIosSearch } from "react-icons/io";

const TokenList = (props) => {

    // token list data  
    const [tokenList, setTokenList] = useState(false)


    // api to fetch dummy data 

    const TokenListFetchHandler = async () => {

        try {
            const data = await fetch("https://dummyjson.com/users");
            const Res = await data.json();
            setTokenList(Res.users)
        }

        catch (err) {
            console.log(err);
        }

    }

    useEffect(() => {
        TokenListFetchHandler();
    }, [])



    console.log(tokenList);


    return (
        <div className={`${as.TokenListCont} d-flex justify-content-center align-items-start`}  >
            {/* <div className={`${as.darkBackground}`}  > </div> */}

            {/* token list container  */}
            <div className={`${as.TokenListBox} d-flex flex-column gap-3`}  >

                <div className={`${as.popupHeader} `}>
                    <h4 className="fw-bold"  >Select a token</h4>
                    <h1 className="cursor-pointer" >
                        <MdClose className="fw-bold cursor-pointer" onClick={()=>props.TokenListVisHandler()} />
                    </h1>
                </div>

                {/* search tokens  input  */}
                <div className={as.coinSearchDiv}  >

                    <input type='text' placeholder='Searach name or paste address '  ></input>
                    <span className='cursor-pointer'>
                        <IoIosSearch></IoIosSearch>
                    </span>
                </div>


                {/* token name list  */}
                <div className={`${as.coinListDiv} `}  >

                    {/* head  */}
                    <h6>
                        Token name
                    </h6>

                    {/* list  */}
                    <ul>

                        {
                            tokenList ? tokenList.map((data, i) => {
                                return (
                                    <li>
                                        <img src={data.image}   ></img>
                                        <span>{data.firstName}</span>
                                    </li>
                                )
                            })

                                : null
                        }
                    </ul>


                </div>


            </div>


        </div>
    )
}

export default TokenList