import React, { useEffect, useMemo, useState } from 'react'
import as from "./Landing2.module.css"
import { AgGridReact } from 'ag-grid-react'; // React Grid Logic
import "ag-grid-community/styles/ag-grid.css"; // Core CSS
import "ag-grid-community/styles/ag-theme-quartz.css"; // Theme
// import { btcb_, volume_ } from '../../App';

const Landing2 = () => {


  // cellRenderer 
  const SimpleComp = p => {
    return (
      <> <img style={{ width: "1rem" }} src={p.value}></img></>
    )
  }


  // Row Data: The data to be displayed.
  const [rowData, setRowData] = useState([

    { image: "", Name: "Bitcoin", Symbol: "Btc", MarketCap: "Cape Canaveral", Price: "$40001.047", "24H Change": "12.0256%" },
    { image: "", Name: "Bit torent", Symbol: "Bttc", MarketCap: "Kennedy Space Center", Price: "$2,354.70", "24H Change": "2.23%" },
    { image: "", Name: "Solana", Symbol: "Sol", MarketCap: "Cape Canaveral", Price: "$72.23", "24H Change": "2.562%" }

  ]);

  // Column Definitions: Defines & controls grid columns.
  const [colDefs, setColDefs] = useState([

    // { , field: "Name" },
    // { field : "Name"  },
    { cellRenderer: SimpleComp, field: "image" },  //change field value as your header value
    { field: "firstName" },  //change field value as your header value
    // { cellRenderer: SimpleComp , field: "firstName" },  //change field value as your header value
    { field: "email" },      //change field value as your header value
    { field: "lastName" },   //change field value as your header value
    { field: "phone" }      //change field value as your header value


  ]);


  const defaultColDef = useMemo(() => ({
    resizable: true,
    flex: 1
  }))


  const fetchListHandler = async () => {
    try {

      const data = await fetch("https://dummyjson.com/users");
      const Res = await data.json();


      setRowData(Res.users)
      // setImagesList(Res.users)
    }
    catch (err) {
      console.log(err);
    }
  }


  useEffect(() => {

    fetchListHandler();
  }, [])



  // console.log("imageList=>>>",imageList);
  console.log(rowData);
  // console.log("rowData=>>",rowDatas);





  return (

    // Container
    <div className={`${as.Landing2Cont} mt-5  `}   >

      {/* The AG Grid component */}
      <div className={`${as.tablecont} bg-white ag-theme-quartz pt-5`}    >
        <AgGridReact

          defaultColDef={defaultColDef}
          rowData={rowData}
          pagination={true}
          columnDefs={colDefs}

        />
      </div>



    </div>
  )
}

export default Landing2