import React from 'react'

const BuyCrypto = () => {
  return (
    <div>BuyCrypto</div>
  )
}

export default BuyCrypto